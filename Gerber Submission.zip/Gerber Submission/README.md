# Gerber Submission
The renders folder holds the CAM outputs for the board submission, if it were to be manufactured 
